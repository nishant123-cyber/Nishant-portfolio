# Nishant Kumar Portfolio

A modern, animated portfolio website built with vanilla HTML, CSS, and JavaScript.

## Features
- Smooth scrolling navigation
- Animated SVG drawings
- Responsive design (mobile-friendly)
- Dark theme with glowing accents
- Skill cards with hover animations
- Project showcase
- Contact form integrated with FormSubmit.co

## Files Included
- `index.html` - Main portfolio file (all CSS and JS included)
- `.gitignore` - Git configuration file
- `README.md` - This file

## Quick Setup & Deployment Guide

### Step 1: Create a GitHub Repository
1. Go to https://github.com/new
2. Name it: `nishant-portfolio` (or any name you prefer)
3. Add description: "My professional portfolio"
4. Keep it **Public** (important for Netlify)
5. Click "Create repository"

### Step 2: Clone to Your Computer (via Git)
On your laptop/computer:
```bash
git clone https://github.com/YOUR_USERNAME/nishant-portfolio.git
cd nishant-portfolio
```

### Step 3: Add Portfolio Files
1. Copy `index.html` into the folder
2. Push to GitHub:
```bash
git add index.html
git commit -m "Add portfolio website"
git push origin main
```

### Step 4: Deploy on Netlify
1. Go to https://netlify.com
2. Sign up (use GitHub login for easiest setup)
3. Click "New site from Git"
4. Select "GitHub" and authorize
5. Select your `nishant-portfolio` repository
6. Click "Deploy"

**That's it!** Your portfolio is now live at a Netlify URL.

### Step 5: Get a Custom Domain (Optional)
In Netlify dashboard:
- Go to Domain settings
- Add custom domain (buy or connect existing)

## Customization
Edit `index.html` to change:
- Name and title (Line 9, 890, 918)
- About section (Line 1050-1052)
- Skills (Lines 1072-1104)
- Projects (Lines 1122-1146)
- Contact email (Line 1160)
- Social links (Lines 1001, 1018)

## Technologies Used
- HTML5
- CSS3 (with animations)
- Vanilla JavaScript
- FormSubmit.co for contact form
- Google Fonts (Inter)

## Contact Form
The contact form sends emails to `nishantkr6783@gmail.com`. 
To change: Update line 1160 in index.html with your email.

---
Portfolio created with ❤️ in 2026

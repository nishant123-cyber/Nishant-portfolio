# COMPLETE STEP-BY-STEP DEPLOYMENT GUIDE
## Deploy Your Portfolio Like Arushi Did

---

## PART 1: SETUP GITHUB (5 mins)

### What is GitHub?
GitHub is like a cloud storage for code. It's where you upload your files so Netlify can access them.

### Steps:

**Step 1.1: Create a GitHub Account (if you don't have one)**
- Go to https://github.com/signup
- Enter email, password, username
- Verify email
- ✅ Done!

**Step 1.2: Create a New Repository**
- Go to https://github.com/new
- Name: `nishant-portfolio`
- Description: "My professional portfolio website"
- Keep it **PUBLIC** ⭐ (IMPORTANT!)
- Click green button "Create repository"
- ✅ You're on your repo page now!

**Step 1.3: Upload Files to GitHub (Easy Web Method)**

Right now you have a blank repository. We need to add files:

Option A: **Quick Upload (No Git required)**
- On your repo page, click "Add file" → "Upload files"
- Drag and drop (or select) these 3 files:
  1. index.html
  2. README.md
  3. .gitignore
- Click "Commit changes"
- ✅ Files uploaded!

Option B: **Using Git Command Line** (More professional)
*If you installed Git on your laptop:*
```bash
git clone https://github.com/YOUR_USERNAME/nishant-portfolio.git
cd nishant-portfolio
# Copy index.html, README.md, .gitignore into this folder
git add .
git commit -m "Initial portfolio upload"
git push origin main
```

---

## PART 2: DEPLOY TO NETLIFY (5 mins)

### What is Netlify?
Netlify is a hosting service. It takes your files from GitHub and makes them live on the internet!

### Steps:

**Step 2.1: Sign Up on Netlify**
- Go to https://netlify.com
- Click "Sign up"
- Choose "Sign up with GitHub" (easiest!)
- Click "Authorize netlify" button
- ✅ You're logged in!

**Step 2.2: Connect Your Repository**
- On Netlify dashboard, click "New site from Git"
- Click "GitHub"
- You might need to authorize again
- Search for `nishant-portfolio` repo
- Click it to select
- ✅ GitHub is connected!

**Step 2.3: Configure & Deploy**
- Leave all settings as default (Deploy button, branch = main)
- Scroll down, click "Deploy site"
- Wait 30-60 seconds...
- **You'll see:** "Your site is live at: https://[random-name].netlify.app"
- ✅ DEPLOYED! 🎉

---

## PART 3: VERIFY YOUR PORTFOLIO IS LIVE

1. Click the Netlify link from Step 2.3
2. Your portfolio should load!
3. Test all sections:
   - Click sidebar links (Home, About, Skills, Projects, Contact)
   - Hover over skill cards (they should glow)
   - Try the contact form
   - Check on mobile (should be responsive)

---

## PART 4: CUSTOMIZE YOUR PORTFOLIO

You've deployed it, now make it yours!

### Edit Your Portfolio (on laptop):
1. Open `index.html` with any text editor (VS Code, Notepad, etc.)
2. Find and replace:

| What to Change | Line # | Example |
|---|---|---|
| Your name | 890, 918 | Change "Nishant" to your name |
| About description | 1050-1052 | Your own bio |
| Skills | 1072-1104 | Add/remove skills |
| Projects | 1122-1146 | Your project names & descriptions |
| Contact email | 1160 | Change to your email |
| LeetCode link | 1001 | Your LeetCode profile URL |
| Codeforces link | 1018 | Your Codeforces profile URL |

### Push Changes to Live Site:
After editing `index.html`:

**Option A: Web Upload**
- Go to your GitHub repo
- Click "index.html" → click pencil icon (edit)
- Paste your updated code
- Click "Commit changes"
- Wait 1-2 mins → Netlify auto-updates your site!

**Option B: Git Command**
```bash
cd nishant-portfolio
# Edit index.html with text editor
git add index.html
git commit -m "Update portfolio content"
git push origin main
# Site updates automatically!
```

---

## PART 5: GET A CUSTOM DOMAIN (Optional)

Right now your site is at: `https://[random].netlify.app`

Want a cool domain like `nishant-portfolio.com`?

**Option 1: Buy through Netlify**
- In Netlify dashboard → Domain settings
- Click "Add custom domain"
- Enter domain name
- Follow payment steps (~₹500-1000/year)

**Option 2: Buy from Namecheap/GoDaddy**
- Buy domain separately
- In Netlify → Domain settings → Add domain
- Connect your domain
- Follow DNS setup instructions

---

## TROUBLESHOOTING

### Site shows blank page?
- Make sure file is named exactly `index.html`
- Check GitHub has the file
- Hard refresh browser (Ctrl+Shift+R or Cmd+Shift+R)

### Changes not showing?
- Wait 1-2 minutes for Netlify to rebuild
- Hard refresh browser
- Check "Deploys" tab in Netlify for errors

### Contact form not working?
- Make sure email in `index.html` line 1160 is correct
- Test with your own email first
- FormSubmit is free and requires no backend setup

### Mobile looks weird?
- The CSS is responsive but only tested on common sizes
- If layout breaks, reduce font sizes or adjust spacing in CSS

---

## QUICK REFERENCE COMMANDS

If using Git on laptop:

```bash
# First time setup
git clone https://github.com/YOUR_USERNAME/nishant-portfolio.git
cd nishant-portfolio

# Every time you make changes
git add .
git commit -m "Update description"
git push origin main

# View status
git status
```

---

## LINKS YOU'LL NEED

Save these!
- GitHub: https://github.com
- Netlify: https://netlify.com
- Your Repo: https://github.com/YOUR_USERNAME/nishant-portfolio
- Your Site: https://[random-name].netlify.app

---

## SUCCESS CHECKLIST

- [ ] Created GitHub account
- [ ] Created `nishant-portfolio` repository (PUBLIC)
- [ ] Uploaded index.html, README.md, .gitignore
- [ ] Connected GitHub to Netlify
- [ ] Site deployed and live at Netlify URL
- [ ] Tested all sections load correctly
- [ ] Customized with your own content
- [ ] Changes pushed and updated live
- [ ] Portfolio is complete! 🎉

---

**Questions?** Review this guide again or ask Claude for help!

Good luck! Your portfolio is going to look amazing! 💪
